from flask import Flask, render_template
import pandas as pd
import flask

app = Flask(__name__)

df = pd.read_csv('data.csv')
@app.route('/')
def hello():
    names = []
    for index, row in df.iterrows():
        names.append({'MMSI': str(row['mmsi']),'name' : row['name'],'flag': row['flag'], "action": "<a class='btn btn-success form-control' href='check/"+row['name']+"'>Check</a>"})
    print(names)
    return render_template('index.html', Pokemons = names, len = len(names),)


@app.route('/check/<name>')
def show_user_profile(name):
    row = df.loc[df['name'] == name]
    # print(row)
    src_lat = float(row['des_lat'])
    src_lon = float(row['src_lon'])
    des_lat = float(row['des_lat'])
    des_lon = float(row['des_lon'])
    coor = [{"lat": src_lat, "lng": src_lon},{"lat": des_lat, "lng": des_lon}]
    eta = str(pd.to_datetime(row['end_time']) - pd.to_datetime(row['start_time']))[2:].strip().split('\n')[0]
    return render_template('check.html',coor=coor, eta=eta, title=name)

if __name__ == "__main__":
    app.run(debug=True)